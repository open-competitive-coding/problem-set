# Echo the input

Your mission should you choose to accept it is to echo the input provided in STDIN to STDOUT.
